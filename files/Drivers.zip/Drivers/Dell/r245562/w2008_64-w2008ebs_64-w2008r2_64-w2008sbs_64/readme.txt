                       Broadcom NetXtreme Unified iSCSI Crash Dump Driver

                  Copyright (c) 2000-2009 Broadcom Corporation
                              All rights reserved.

                               January 1, 2009

This file describes the Broadcom iSCSI Unified Crash Dump Driver.  This driver
support NetXtreme I, NetXtreme II 1G, and NetXtreme II 10G devices. Broadcom 
Unified iSCSI Crash Dump driver is released with the following binaries:

bnxcdx.sys : Crash Dump driver for x86 Win2k3/Win2k8 environment.

bnxcd64.sys : Crash Dump driver for x64 Win2k3/Win2k8 environment.

These drivers work with both scenarios where system is either booted in
non-offload path with MSFT iSCSI Initiator or offload path with Broadcom
iSCSI offload driver.














